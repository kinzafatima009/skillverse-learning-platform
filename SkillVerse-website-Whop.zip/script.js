const courses = [
  ["🎨","Graphic Design","Design","Learn visual design, layouts and branding.","12 lessons","c1"],
  ["📣","Digital Marketing","Business","Understand content, social media and marketing basics.","15 lessons","c2"],
  ["💻","Web Development","Tech","Build your first responsive websites from scratch.","18 lessons","c3"],
  ["✍️","Content Writing","Creative","Write clearer posts, articles and portfolio pieces.","10 lessons","c4"],
  ["📊","Data Basics","Tech","Learn spreadsheets, charts and practical data thinking.","14 lessons","c5"],
  ["🎬","Video Editing","Creative","Learn the foundations of modern short-form editing.","16 lessons","c6"]
];

const courseGrid = document.getElementById("courseGrid");
courseGrid.innerHTML = courses.map((c,i)=>`
  <article class="course">
    <div class="course-top"><span class="course-icon ${c[5]}">${c[0]}</span><span class="tag">${c[2]}</span></div>
    <h3>${c[1]}</h3><p>${c[3]}</p>
    <div class="course-foot"><span>${c[4]}</span><b>${i<2?"Popular":"Explore"} →</b></div>
  </article>`).join("");

const modal=document.getElementById("modal"), modalContent=document.getElementById("modalContent");
function openModal(html){modalContent.innerHTML=html;modal.classList.add("show")}
function closeModal(){modal.classList.remove("show")}
modal.addEventListener("click",e=>{if(e.target===modal)closeModal()});
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function scrollToId(id){document.getElementById(id)?.scrollIntoView({behavior:"smooth"})}
function openLogin(){
 openModal(`<h2>Welcome back 👋</h2><p>Sign in to save progress, streaks and XP.</p>
 <input placeholder="Email address"><input type="password" placeholder="Password">
 <button class="btn" onclick="showToast('Demo login — connect Firebase/Supabase for real accounts.');closeModal()">Log in</button>`);
}
function openPremium(){
 window.open("https://whop.com/skillspring-learning-platform-vsp0/website-25-dae3/","_blank","noopener,noreferrer");
}
function openRoadmap(){
 openModal(`<h2>Build your roadmap 🗺️</h2><p>Choose a goal and we'll create a simple learning path.</p>
 <button class="outline" onclick="makeRoadmap('Freelancing')">💼 Start freelancing</button><br><br>
 <button class="outline" onclick="makeRoadmap('Creative skills')">🎨 Creative skills</button><br><br>
 <button class="outline" onclick="makeRoadmap('Tech skills')">💻 Tech skills</button>`);
}
function makeRoadmap(goal){
 openModal(`<h2>${goal} roadmap 🚀</h2><p><b>Week 1:</b> Learn the basics<br><b>Week 2:</b> Practice with mini challenges<br><b>Week 3:</b> Build a small project<br><b>Week 4:</b> Polish your project and create a portfolio piece</p><button class="btn" onclick="closeModal()">Start learning →</button>`);
}

const quiz = [
 ["Which skill is mainly about making websites?","Web Development",["Web Development","Content Writing","Video Editing","Copywriting"]],
 ["What does SEO help improve?","Search visibility",["Search visibility","Battery life","Photo resolution","Typing speed"]],
 ["Which is a visual design tool concept?","Typography",["Typography","Accounting","Networking","Algebra"]],
 ["What is a portfolio?","A collection of your work",["A collection of your work","A password","A payment receipt","A browser"]],
 ["What helps you improve a skill?","Practice",["Practice","Ignoring feedback","Skipping lessons","Random guessing"]]
];
let qIndex=0,score=0;
function startQuiz(){qIndex=0;score=0;renderQuestion()}
function renderQuestion(){
 const q=quiz[qIndex];
 openModal(`<span class="eyebrow">SKILL SPRINT · ${qIndex+1}/${quiz.length}</span><div class="game-question">${q[0]}</div><div class="answers">${q[2].map(a=>`<button onclick="answerQuiz('${a.replace(/'/g,"\\'")}')">${a}</button>`).join("")}</div>`);
}
function answerQuiz(answer){
 if(answer===quiz[qIndex][1])score++;
 qIndex++;
 if(qIndex<quiz.length)renderQuestion();
 else openModal(`<h2>🎉 Quiz complete!</h2><p>You scored <b>${score}/${quiz.length}</b>. ${score>=4?"Excellent work!":"Keep practicing — every attempt helps."}</p><button class="btn" onclick="closeModal();showToast('+'+(score*20)+' XP earned!')">Claim XP</button>`);
}
function startMemory(){
 const pairs=[["🎨","Design"],["💻","Code"],["📣","Marketing"],["🎬","Video"]];
 let shuffled=[...pairs].sort(()=>Math.random()-.5);
 openModal(`<h2>🧩 Memory Match</h2><p>Match each emoji with the correct skill. This demo gives you a quick learning challenge.</p>
 <div class="answers">${shuffled.map(x=>`<button onclick="memoryPick('${x[1]}')">${x[0]} → ${x[1]}</button>`).join("")}</div>`);
}
function memoryPick(skill){showToast("Nice match! +25 XP");closeModal()}
function startTyping(){
 const words=["creative","learning","portfolio","marketing","website","future"];
 const word=words[Math.floor(Math.random()*words.length)];
 openModal(`<h2>⌨️ Typing Rush</h2><p>Type this word as quickly as you can:</p><div style="font:700 28px Space Grotesk;text-align:center;margin:22px 0">${word}</div><input id="typeInput" autofocus placeholder="Type here..." oninput="checkTyping('${word}')"><p id="typingStatus"></p>`);
 setTimeout(()=>document.getElementById("typeInput")?.focus(),100);
}
function checkTyping(word){
 const input=document.getElementById("typeInput"),status=document.getElementById("typingStatus");
 if(input.value.toLowerCase()===word){status.innerHTML="🎉 Correct! +30 XP";setTimeout(closeModal,700)}
}
function toggleMenu(){showToast("On small screens, use the page sections below to navigate.")}
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
