# SkillVerse

A polished, responsive learning-platform front end with:
- Course discovery cards
- Premium pricing UI
- Roadmap builder
- XP/streak concept
- Three mini-games
- Responsive mobile layout
- Demo login and premium checkout flows

## Run locally
Open `index.html` in a browser.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select `main` and `/root`.
6. Save and wait for the Pages URL.

## Turning the demo into a real business
The current project is a front-end prototype. Before accepting real payments or storing user accounts, add:
- Authentication: Firebase Auth or Supabase Auth
- Database: Supabase/PostgreSQL or Firebase
- Payments: Stripe or another provider available for your business/location
- Server-side premium entitlement checks
- Privacy policy and terms
- Analytics and error monitoring

Do not put secret API keys in `script.js` or any GitHub Pages frontend file.

## Monetization structure
Possible revenue streams:
1. Monthly/annual Premium subscriptions
2. Creator subscription
3. Paid digital courses/resources
4. Carefully selected sponsorships
5. Affiliate links where appropriate

Revenue is not guaranteed; actual earnings depend on traffic, conversion, pricing, costs, and applicable platform/payment rules.


## Whop Premium
The Premium buttons open the supplied Whop page in a new tab:
https://whop.com/skillspring-learning-platform-vsp0/website-25-dae3/
